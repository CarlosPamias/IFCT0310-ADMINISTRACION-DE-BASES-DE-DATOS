<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Listado todas las rutas</title>
    <style>
        table, th, td {
            border: 1px solid black;
            width: 500px;
            text-align: center;

        }
        th {
            background-color: #000;
            color: #fff;
        }
        tr:nth-child(odd) {
            background-color: burlywood;
        }
       
    </style>
    <body>
        <?php
 
        // Variables
        $conexion=mysqli_connect("localhost", "root", "", "itinerario");

        // Consulta
        $consulta = "SELECT * FROM rutas";
        $resultado = mysqli_query($conexion, $consulta);
      
        echo "Listado de todas las rutas:<br><br>";
        echo "<table><tr><th>Ruta</th><th>Inicio</th><th>Final</th><th>Altura Maxima</th><th>Altura Minima</th><th>Desnivel Acumulado</th><th>Distancia</th><th>Nivel</th><th>Medio</th>";

        //bucle para mostrar los resultados
        while($fila = mysqli_fetch_array($resultado)) {
            // Imprimimos los valores del array bidimensional
            echo "<tr>";
            echo "<td>". $fila['ruta']. "</td>";
            echo "<td>". $fila['inicio']. "</td>";
            echo "<td>". $fila['final']. "</td>";
            echo "<td>". $fila['alturaMaxima']. "</td>";
            echo "<td>". $fila['alturaMinima']. "</td>";
            echo "<td>". $fila['desnivelAcumulado']. "</td>";
            echo "<td>". $fila['distancia']. "</td>";
            echo "<td>". $fila['nivel']. "</td>";
            echo "<td>". $fila['medio']. "</td>";
            echo "</tr>";

           
        }
        echo "</tr>"; 
        echo "</table>";
        // cerrar la conexión
        mysqli_close($conexion);
        echo "<br><a href='index.html'>Volver al inicio</a>";
        ?>
        </head>
        <body>    
