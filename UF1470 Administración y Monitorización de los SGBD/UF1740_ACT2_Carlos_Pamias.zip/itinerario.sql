-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 06-09-2024 a las 14:22:11
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `itinerario`
--
CREATE DATABASE IF NOT EXISTS `itinerario` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `itinerario`;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `rutas`
--

CREATE TABLE `rutas` (
  `ruta` varchar(20) DEFAULT NULL,
  `inicio` varchar(20) DEFAULT NULL,
  `final` varchar(9) DEFAULT NULL,
  `alturaMaxima` int(4) DEFAULT NULL,
  `alturaMinima` int(12) DEFAULT NULL,
  `desnivelAcumulado` int(10) DEFAULT NULL,
  `distancia` float DEFAULT NULL,
  `nivel` varchar(10) DEFAULT NULL,
  `medio` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Volcado de datos para la tabla `rutas`
--

INSERT INTO `rutas` (`ruta`, `inicio`, `final`, `alturaMaxima`, `alturaMinima`, `desnivelAcumulado`, `distancia`, `nivel`, `medio`) VALUES
('Parenzana', 'Parenzana', 'Parenzana', 0, 294, 1355, 62, 'Medio', 'Bicicleta'),
('Rovinj-aajini-Rovinj', 'Rovinj', 'Rovinj', 303, 0, 846, 71, 'Medio', 'Bicicleta'),
('Santurce-Bilbao', 'Santurce', 'Bilbao', 10, 30, 120, 12, 'Bajo', 'Caminar'),
('Pelpedrega', 'Queralbs', 'Nuria', 1243, 1997, 754, 7, 'Alto', 'Caminar'),
('Reus - Paris', 'Reus', 'Paris', 50, 150, 100, 1750, 'alto', 'bicicleta'),
('Viella - Betren', 'Viella', 'Betren', 1000, 1200, 200, 15, 'bajo', 'caminar');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
