
    <?php

    $conexion=mysqli_connect("localhost", "root", "", "itinerario");
    
    $ruta = $_POST['ruta'];
    $inicio = $_POST['inicio'];
    $final = $_POST['final'];
    $alturaMaxima = $_POST['alturaMaxima'];
    $alturaMinima = $_POST['alturaMinima'];
    $desnivelAcumulado = $_POST['desnivelAcumulado'];
    $distancia = $_POST['distancia'];
    $nivel = $_POST['nivel'];
    $medio = $_POST['medio'];
   
    $instruccion = "INSERT INTO rutas VALUES('$ruta', '$inicio', '$final', '$alturaMaxima', '$alturaMinima', '$desnivelAcumulado', '$distancia', '$nivel', '$medio')";
    $ejecurarInsertar = mysqli_query($conexion, $instruccion);

   
    echo "Nombre agregado correctamente";
    echo "<br><a href='index.html'>Volver al inicio</a>";
    echo "<br><a href='listadoRutas.php'>Listado de todas las rutas.</a>";
    echo "<br><a href='formulario.html'>Introducir otra ruta</a>";
    // cerrar la conexión
    mysqli_close($conexion)
    ?>
