<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Array bidimensional</title>
    <style>
        table, th, td {
            border: 1px solid black;
            width: 400px;
            text-align: center;

        }
        th {
            background-color: #000;
            color: #fff;
        }
        tr:nth-child(odd) {
            background-color: burlywood;
        }
       
    </style>
</head>
<body>
    <?php
    // Definimos un array bidimensional
    $usuario = array(
        array("Benito","Bodoque", "benito@tal.com"),
        array("Bart","Simpson", "bart@tal.com"),
        array("Maria","Delau", "delau@tal.com"),
        array("Demostenes","Papadoulus", "papad@tal.com")
    );
    
    // Imprimimos los valores del array bidimensional

    echo "Listado de usuarios e E-mail:<br>";
    echo "<table><tr><th>Nombre</th><th>Apellido</th><th>E-Mail</th>";

    for ($i = 0; $i <count($usuario); $i++) {
        echo "<tr>";
        for($j = 0; $j <3; $j++) {
           // if ($j == 0) {echo "<li>";}
            echo "<td>". $usuario[$i][$j]. "</td>";
        }
    echo "</tr>"; 
    }
    echo "</table>";
    ?>
</body>
</html>