<!DOCTYPE html>
<html lang="en">
   <head>
       <meta charset="utf-8">
       <title>Lectura de un fichero de datos XML</title>
   </head>
           
   <body>
        <?php
        // Cargar el archivo XML
        $xml = simplexml_load_file('cursos.xml');
       
        // Encontrar todos los elementos 'nombre' dentro de 'curso'
        $nombres_cursos = [];
        foreach ($xml->cursosInformatica->curso as $curso) {
            echo $curso->nombre. "<br/>";
        }
        ?>

   </body>
           
</html>