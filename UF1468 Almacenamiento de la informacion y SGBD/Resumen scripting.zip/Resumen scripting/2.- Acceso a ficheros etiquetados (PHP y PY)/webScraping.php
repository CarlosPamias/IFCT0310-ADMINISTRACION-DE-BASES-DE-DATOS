 <!DOCTYPE html>
<html lang="es">
   <head>
       <meta charset="utf-8">
       <title>Web scrapping</title>
   </head>
           
   <body>
   <?php
        // Cargar el archivo HTML
        $html = file_get_contents('https://app.projecte4estacions.com/index.php');

        // Crear un nuevo objeto DOMDocument
        $dom = new DOMDocument();

        // Cargar el HTML en el objeto DOMDocument
        $dom->loadHTML($html);

        // Obtener todas las etiquetas <a> del documento
        $enlaces = $dom->getElementsByTagName('a');

       
        // Iterar sobre los enlaces y mostrar sus atributos
        foreach ($enlaces as $enlace) {
            // Obtener el atributo 'href' de cada enlace
            $href = $enlace->getAttribute('href');
            // Obtener el texto dentro del enlace
            $texto = $enlace->nodeValue;
            // Mostrar el enlace y su texto
            echo "Enlace: $texto ($href) <br>";
        }
        ?>


   </body>
           
</html>