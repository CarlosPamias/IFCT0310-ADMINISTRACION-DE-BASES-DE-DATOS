from bs4 import BeautifulSoup
# Para cargar una URL remota
import requests
url='https://paucasals.com/index.php'
respuesta = requests.get(url)
contenidoWeb= respuesta.text
print(contenidoWeb)

# Usando una variable local
raw_html = """
<h1>Used cars for sale</h1>
<ul class="cars-listing">
    <li class="car-listing">
        <div class="car-title">
            Volkswagen Beetle
        </div>
        <div class="car-description">
            <span class="car-make">Volkswagen</span>
            <span class="”car-model”">Beetle</span>
            <span class="car-build">1973</span>
        </div>
        <div class="sales-price">
            € <span class="”car-price”">14,998.—</span>
        </div>
    </li>
</ul>
 """
# parse the HTML source code stored in raw_html
html = BeautifulSoup(raw_html, 'html.parser')
# extract the content of the tag with the class 'car-title'
car_title = html.find(class_ = 'car-title').text.strip()
# if this car is a Volkswagen Beetle
if (car_title == 'Volkswagen Beetle'):
    # jump up from the car title to the wrapping <li> tag</li>
    html.find_parent('li')
    
    # find the car price
    car_price = html.find(class_ = 'sales-price').text.strip()
    
    # output the car price
    print(car_price)