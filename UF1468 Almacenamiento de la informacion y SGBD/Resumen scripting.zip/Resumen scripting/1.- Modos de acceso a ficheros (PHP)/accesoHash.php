<!DOCTYPE html>
<html lang="en">
   <head>
       <meta charset="utf-8">
       <title>Acceso hash a ficheros</title>
   </head>
           
   <body>
        <?php
        // Función para calcular el hash de una cadena
        function calcularHash($cadena) {
            return hash('sha256', $cadena);
        }

        // Nombre del archivo de datos
        $nombreArchivo = "datosEtiquetados.txt";

        // Clave a localizar
        $clave="Sección 1";
        $hash=calcularHash($clave);
        echo "La clave buscada es '$clave' y tiene como hash '$hash'. Su contenido en el archivo es:<br/>";

        // Abrir el archivo
        $archivo = fopen($nombreArchivo, "r");
                
        // Buscar la etiqueta en el archivo y mostrar el contenido
        while (($linea = fgets($archivo))) {        
            if(strpos($linea, '[' .$hash. ']') !== false) {
                // Imprimir el contenido de la sección
                while (($linea = fgets($archivo)) !== false && strpos($linea, '[') === false) {
                    echo $linea.'<br/>';
                }
                break;
            }
        }
                
        // Cerrar el archivo
        fclose($archivo);
        ?>

   </body>
           
</html>