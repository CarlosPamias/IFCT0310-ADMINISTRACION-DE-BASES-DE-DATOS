<!DOCTYPE html>
<html lang="en">
   <head>
       <meta charset="utf-8">
       <title>Acceso directo a ficheros</title>
   </head>
           
   <body>
        <?php
        // Ruta al archivo
        $ruta_archivo = 'datos.txt';

        // ID del empleado que quieres buscar
        $id_empleado = 3;

        // Tamaño de cada registro (en caracteres)
        $tamano_registro = 55; // 55 caracteres por línea (incluyendo el salto de línea CR+LF)
        // Tamaño de la cabecera
        $tamano_cabecera = 116+1; 

        // Calcular el desplazamiento para el registro con el ID buscado
        $desplazamiento = $tamano_cabecera + ($id_empleado - 1) * $tamano_registro;

        // Abrir el archivo
        $archivo = fopen($ruta_archivo, 'r');

        // Verificar si se pudo abrir el archivo correctamente
        if ($archivo) {
            // Mover el puntero al inicio del registro deseado
            fseek($archivo, $desplazamiento);

            // Leer el contenido del registro
            $registro = fgets($archivo);
            
            // Cerrar el archivo
            fclose($archivo);

            // Mostrar el contenido del registro
            echo "Información del empleado con ID $id_empleado:\n";
            echo $registro;
        } else {
            echo "No se pudo abrir el archivo.";
        }
        ?>

   </body>
           
</html>