<!DOCTYPE html>
<html lang="en">
   <head>
       <meta charset="utf-8">
       <title>Acceso indexado a ficheros</title>
   </head>
           
   <body>
        <?php
        // Abrir el archivo en modo lectura
        $archivo = fopen("datos.txt", "r");

        // Verificar si el archivo se ha abierto correctamente
        if ($archivo) {
            // Leer cada línea del archivo y almacenarla en un array
            $lineas = [];
            while (($linea = fgets($archivo)) != false) {
                $lineas[] = $linea;
            }
            
            //var_dump($lineas);
            //die();
            
            // Cerrar el archivo
            fclose($archivo);

            // Acceder a cada línea utilizando índices
            echo "El primer empleado es: " . $lineas[0+2].'<br/>'; // Hay que saltarse la cabecera
            echo "El segundo empleado es: " . $lineas[1+2].'<br/>';
            echo "El tercer empleado es: " . $lineas[2+2].'<br/>';
        } else {
            // Mostrar un mensaje de error si no se pudo abrir el archivo
            echo "No se pudo abrir el archivo.";
        }
        ?>

   </body>
           
</html>