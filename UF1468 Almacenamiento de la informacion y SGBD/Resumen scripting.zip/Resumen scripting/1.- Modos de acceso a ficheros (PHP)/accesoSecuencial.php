<!DOCTYPE html>
<html lang="en">
   <head>
       <meta charset="utf-8">
       <title>Acceso secuencial a ficheros</title>
   </head>
           
   <body>
        <?php
        // Ruta al archivo
        $ruta_archivo = "datos.txt";

        // Abrir el archivo en modo lectura
        $archivo = fopen($ruta_archivo, "r");

        // Verificar si se abrió correctamente el archivo
        if ($archivo) {
            // Iterar sobre cada línea del archivo
            while (($linea = fgets($archivo)) != false) {
                // Imprimir la línea
                echo $linea . "<br/>";
            }
            
            // Cerrar el archivo
            fclose($archivo);
        } else {
            // Mostrar un mensaje de error si no se puede abrir el archivo
            echo "No se pudo abrir el archivo.";
        }
        ?>  
   </body>
           
</html>