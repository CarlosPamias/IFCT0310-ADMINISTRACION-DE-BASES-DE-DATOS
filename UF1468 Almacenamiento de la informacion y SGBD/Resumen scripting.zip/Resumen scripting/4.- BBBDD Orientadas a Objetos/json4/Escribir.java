import java.util.Scanner;

public class Escribir
{
    public static void main(String[] args) {


         Scanner teclado=new Scanner(System.in);
        System.out.println("Dime tu nombre:");
        
        int opcion=Integer.parseInt(teclado.nextLine());
        System.out.println(opcion==1);
    
        
    }
    
}
