import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.FileReader;
import java.io.BufferedReader;
import java.util.ArrayList;

public class Programa
{
    public static void main(String[] args) {
        
        ArrayList<Estudiante> listaEstudiantes=new ArrayList<Estudiante>();
        
        try {
            ObjectMapper mapeador=new ObjectMapper();
            FileReader archivo=new FileReader("estudiantes.txt");
            BufferedReader buffer=new BufferedReader(archivo);
            
            String linea;
            while((linea=buffer.readLine())!=null) {
                Estudiante es=mapeador.readValue(linea.strip(),Estudiante.class);
                listaEstudiantes.add(es);
            }
            
            buffer.close();
            archivo.close();
            
            System.out.println("Los estudiantes se han leído correctamente, son los siguientes:");
            
            for (Estudiante es:listaEstudiantes) {
                System.out.println(es);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        
    }
}
