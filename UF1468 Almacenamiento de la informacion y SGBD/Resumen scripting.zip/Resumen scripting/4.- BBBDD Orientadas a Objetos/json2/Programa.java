import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.File;

public class Programa
{
    public static void main(String[] args) {
        
        String json="{\"nombreCompleto\":\"pepe\",\"edad\":23,\"casado\":true,\"aficiones\":[\"correr\",\"pescar\",\"esquiar\"]}";
        
        
        try {
            ObjectMapper mapeador=new ObjectMapper();
            Estudiante estudiante=mapeador.readValue(json,Estudiante.class);
            System.out.println(estudiante);
            
            estudiante.setNombreCompleto("María");
            estudiante.setCasado(false);
            String json2=mapeador.writeValueAsString(estudiante);
            System.out.println(json2);
            
            estudiante.setNombreCompleto("María Antonieta");
            mapeador.writeValue(new File("estudiante.json"),estudiante);
            
            
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        
    }
}
