import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.FileWriter;

public class Programa
{
    public static void main(String[] args) {
        
        Estudiante estudiante1=new Estudiante("Juan",30,true,new String[] {"leer","correr","viajar"});
        Estudiante estudiante2=new Estudiante("María",20,false,new String[] {"comer","estudiar","deporte"});
        
        
        
        
        
        
        try {
            ObjectMapper mapeador=new ObjectMapper();
            FileWriter archivo=new FileWriter("estudiantes.txt");
            
            String jsonEstudiante1=mapeador.writeValueAsString(estudiante1);
            archivo.write(jsonEstudiante1+"\n");
            
            String jsonEstudiante2=mapeador.writeValueAsString(estudiante2);
            archivo.write(jsonEstudiante2+"\n");
            
            archivo.close();
            
            System.out.println("Los estudiantes se han exportado correctamente");
        } catch (Exception e) {
            e.printStackTrace();
        }
        
    }
}
