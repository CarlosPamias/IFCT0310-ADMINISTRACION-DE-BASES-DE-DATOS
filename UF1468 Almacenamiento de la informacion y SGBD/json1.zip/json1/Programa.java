public class Programa
{
    public static void main(String[] args) {
        Estudiante juan;
        Estudiante maria;
        
        juan=new Estudiante("JUAN",30);
        maria=new Estudiante("MARIA",35);
        
        juan.setNombre("JUANITO");
        maria.setEdad(15);
        
        System.out.println(juan);
        System.out.println(maria.toJSON());
        System.out.println(maria.esMayor());
    }
}
