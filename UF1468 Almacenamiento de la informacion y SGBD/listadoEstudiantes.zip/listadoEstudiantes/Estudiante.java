/**
 * Esta es una clase de ejemplo
 * 
 * @author JUAN PEDRO
 * @version 01/07/2024
 */
public class Estudiante
{

    private String nombreCompleto;
    private int edad;
    private boolean casado;
    private String[] aficiones;
    public static int numEstudiantes=0;
    
    public Estudiante() {
        this.nombreCompleto=null;
        this.aficiones=null;
        numEstudiantes++;
    }
    
    /**
     * Constructor for objects of class Estudiante
     */
    public Estudiante(String pNombre, int pEdad, boolean pCasado, String[] pAficiones) {
        this.nombreCompleto=pNombre;
        this.setEdad(pEdad);
        this.casado=pCasado;
        this.aficiones=pAficiones;
        numEstudiantes++;
    }

    public String getNombreCompleto() {
        return this.nombreCompleto;
    }
    
    public int getEdad() {
        return this.edad;
    }
    
    public boolean getCasado() {
        return this.casado;
    }
    
    public String[] getAficiones() {
        return this.aficiones;
    }
    
    public void setNombreCompleto(String pNombre) {
        this.nombreCompleto=pNombre;
    }
    
    public void setEdad(int pEdad) {
        this.edad=pEdad;
    }
    
    public void setCasado(boolean pCasado) {
        this.casado=pCasado;
    }
    
    public void setAficiones(String[] pAficiones) {
        this.aficiones=pAficiones;
    }
    
    @Override
    public String toString() {
        String cadena=new String("Aficiones: [");
        for (String s:this.aficiones) {
            cadena+=s+",";
        }
        cadena+="]";
        return "Nombre: "+this.getNombreCompleto()+" Edad: "+this.getEdad()+" Casado: "+this.getCasado()+" "+cadena;
    }
    
    public boolean esMayor()  {
        /*if (this.getEdad()>=18) {
            return true;
        } else {
            return false;
        }*/
        return (this.getEdad()>=18?true:false);
    }
    
    public String toJSON() {
        // {"nombreCompleto":"pepe","edad":23}
        return "{\"nombreCompleto\":\""+this.getNombreCompleto()+"\",\"edad\":"+this.getEdad()+"}";
    }
}
