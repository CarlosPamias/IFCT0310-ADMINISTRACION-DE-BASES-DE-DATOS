import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.BufferedReader;
import java.util.ArrayList;
import java.util.Scanner;

public class Programa
{
    private static void imprimirMenu() {
        for (int x=0;x<=40;x++) {
            System.out.println();
        }
        System.out.println("Menú PRINCIPAL");
        System.out.println("--------------");
        System.out.println("1.- Mostrar listado");
        System.out.println("2.- Nuevo estudiante");
        System.out.println("3.- Grabar lista");
        System.out.println("4.- Recuperar lista");
        System.out.println("5.- Salir");
        System.out.println("Opcion: ");
    }
    
    public static void main(String[] args) {
        String nombre;
        int opcion=0;
        int edad;
        boolean casado;
        String[] aficiones;
        ArrayList<Estudiante> listaEstudiantes=new ArrayList<Estudiante>();
        Scanner teclado=new Scanner(System.in);
        ObjectMapper mapeador=new ObjectMapper();

        while (opcion!=5) {
            imprimirMenu();
            try {
                opcion=Integer.parseInt(teclado.nextLine().trim());
            } catch (NumberFormatException ne) {
                System.out.println("Has introducido una opción errònea [Pulsa INTRO]");
                opcion=0;
                teclado.nextLine();
            }
            
            if (opcion==1) {
                System.out.println("\nListado de estudiantes");
                System.out.println("----------------------");
                
                if (!listaEstudiantes.isEmpty()) {
                    for (Estudiante estudiante:listaEstudiantes) {
                        System.out.println(estudiante);
                    }
                } else {
                    System.out.println("Lista vacía...");
                }
                teclado.nextLine();
            } else if (opcion==2) {
                System.out.println("\nIntroduce el NOMBRE del estudiante:");
                nombre=teclado.nextLine();
                System.out.println("Introduce la EDAD del estudiante:");
                edad=Integer.parseInt(teclado.nextLine().trim());
                System.out.println("¿Está casado el estudiante? (S/N):");
                casado=(teclado.nextLine().trim().toUpperCase().equals("S")?true:false);
                System.out.println("Introduce sus aficiones (separadas por coma):");
                aficiones=teclado.nextLine().trim().split(",");
                
                Estudiante estudiante=new Estudiante(nombre,edad,casado,aficiones);
                listaEstudiantes.add(estudiante);
            } else if (opcion==4) {
                try {
                    FileReader archivo=new FileReader("estudiantes.txt");
                    BufferedReader buffer=new BufferedReader(archivo);
                    
                    String linea;
                    while((linea=buffer.readLine())!=null) {
                        Estudiante es=mapeador.readValue(linea.strip(),Estudiante.class);
                        listaEstudiantes.add(es);
                    }
                    
                    buffer.close();
                    archivo.close();
                    System.out.println("Los estudiantes se han leído correctamente.");
                    teclado.nextLine();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            } else if (opcion==3) {
                try {
                    FileWriter archivo=new FileWriter("estudiantes.txt");
                    
                    for (Estudiante estudiante:listaEstudiantes) {
                        String json=mapeador.writeValueAsString(estudiante);
                        archivo.write(json+"\n");
                    }
                    
                    archivo.close();
                    
                    System.out.println("Los estudiantes se han exportado correctamente.");
                    teclado.nextLine();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            
        }
        

       System.out.println("Gracias por usar mi programa :)");
        
    }
}
