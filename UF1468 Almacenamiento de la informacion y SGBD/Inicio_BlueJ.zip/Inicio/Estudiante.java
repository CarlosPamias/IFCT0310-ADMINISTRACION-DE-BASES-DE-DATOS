
/**
 * Esta es una clase de ejemplo
 * 
 * @author JUAN PEDRO
 * @version 01/07/2024
 */
public class Estudiante
{

    private String nombreCompleto;
    private int edad;

    /**
     * Constructor for objects of class Estudiante
     */
    public Estudiante(String pNombre, int pEdad) {
        this.nombreCompleto=pNombre;
        this.setEdad(pEdad);
    }

    public String getNombre() {
        return this.nombreCompleto;
    }
    
    public int getEdad() {
        return this.edad;
    }
    
    public void setNombre(String pNombre) {
        this.nombreCompleto=pNombre;
    }
    
    public void setEdad(int pEdad) {
        this.edad=pEdad;
    }
    
    public String toString() {
        return "Nombre: "+this.getNombre()+" Edad: "+this.getEdad();
    }
    
    public boolean esMayor()  {
        /*if (this.getEdad()>=18) {
            return true;
        } else {
            return false;
        }*/
        return (this.getEdad()>=18?true:false);
    }
}
