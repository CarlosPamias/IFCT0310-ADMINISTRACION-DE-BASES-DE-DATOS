 


/**
 *
**/ 
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;


public class InsertarContactos
{
    // instance variables - replace the example below with your own
    private static final String URL = "jdbc:mysql://localhost:3306/bbdd";
    private static final String USER = "carlos";
    private static final String PASSWORD = "123456";
    
    public static Connection conectar() {
        Connection conexion = null;
        try {
            // Registrar el driver JDBC
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            // Establecer la conexi�n
            conexion = DriverManager.getConnection(URL, USER, PASSWORD);
            System.out.println("Conexi�n exitosa a la base de datos.");
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println("Error al conectar a la base de datos: " + e.getMessage());
        }
        return conexion;
    }
    
    
    public static void main (String [] args) {
        
        Connection conexion = conectar();
        
          // Ejecutar una consulta de ejemplo
        if (conexion != null) {
                
                PreparedStatement sentenciaSQL=null;
                Scanner teclado = new Scanner(System.in);
                
                try {
                      String nombre, apellidos;
                      int edad;

            // Bucle para insertar datos hasta que se ingrese "no"
                    while (true) {
                        System.out.println("Introduce el nombre (o escribe 'no' para salir): ");
                        nombre = teclado.nextLine();
                        if (nombre.equalsIgnoreCase("no")) break;
        
                        System.out.println("Introduce los apellidos: ");
                        apellidos = teclado.nextLine();
        
                        System.out.println("Introduce la edad: ");
                        edad = Integer.parseInt(teclado.nextLine());
        
                        // Insertar datos en la base de datos
                        String insertQuery = "INSERT INTO contactos (nombre, apellidos, edad) VALUES (?, ?, ?)";
                        try (PreparedStatement preparedStatement = conexion.prepareStatement(insertQuery)) {
                            preparedStatement.setString(1, nombre);
                            preparedStatement.setString(2, apellidos);
                            preparedStatement.setInt(3, edad);
                            preparedStatement.executeUpdate();
                        }
                           
                           
                         
                            }
                            
                    
                } catch (SQLException e) {
                    System.out.println("Fallo en la aplicaci�n: "+e.getMessage());
                }
                
            } else {
                System.out.println("No se pudo establecer la conexi�n.");
            
            
            }
    }
    
 
}
